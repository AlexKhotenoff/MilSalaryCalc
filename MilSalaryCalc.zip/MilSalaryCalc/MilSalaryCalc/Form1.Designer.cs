﻿namespace MilSalaryCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.closeButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.rankBox = new System.Windows.Forms.ComboBox();
            this.salRange = new System.Windows.Forms.ComboBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.regionIncreaseBox = new System.Windows.Forms.ComboBox();
            this.northIncreaseBox = new System.Windows.Forms.ComboBox();
            this.premBox = new System.Windows.Forms.ComboBox();
            this.secrBox = new System.Windows.Forms.ComboBox();
            this.expBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.taxBox = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.specBox = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(471, 466);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(95, 42);
            this.closeButton.TabIndex = 10;
            this.closeButton.Text = "Закрыть";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "оклад по званию";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "оклад по должности";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "районный коэффициент";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 231);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "северная надбавка";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 91);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(283, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "премия за добросовестное исполнение обязанностей";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "надбавка за секретность";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 347);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "подоходний налог";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "надбавка за выслугу лет";
            // 
            // rankBox
            // 
            this.rankBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.rankBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.rankBox.FormattingEnabled = true;
            this.rankBox.Location = new System.Drawing.Point(287, 19);
            this.rankBox.Name = "rankBox";
            this.rankBox.Size = new System.Drawing.Size(189, 21);
            this.rankBox.TabIndex = 0;
            this.rankBox.SelectedIndexChanged += new System.EventHandler(this.rankBox_SelectedIndexChanged);
            // 
            // salRange
            // 
            this.salRange.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.salRange.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.salRange.FormattingEnabled = true;
            this.salRange.Location = new System.Drawing.Point(335, 54);
            this.salRange.Name = "salRange";
            this.salRange.Size = new System.Drawing.Size(61, 21);
            this.salRange.TabIndex = 1;
            this.salRange.SelectedIndexChanged += new System.EventHandler(this.salRange_SelectedIndexChanged);
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(14, 466);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(440, 42);
            this.calcButton.TabIndex = 9;
            this.calcButton.Text = "Расчитать";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // regionIncreaseBox
            // 
            this.regionIncreaseBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.regionIncreaseBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.regionIncreaseBox.Enabled = false;
            this.regionIncreaseBox.FormattingEnabled = true;
            this.regionIncreaseBox.Location = new System.Drawing.Point(287, 193);
            this.regionIncreaseBox.Name = "regionIncreaseBox";
            this.regionIncreaseBox.Size = new System.Drawing.Size(61, 21);
            this.regionIncreaseBox.TabIndex = 5;
            this.regionIncreaseBox.SelectedIndexChanged += new System.EventHandler(this.regionIncreaseBox_SelectedIndexChanged);
            // 
            // northIncreaseBox
            // 
            this.northIncreaseBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.northIncreaseBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.northIncreaseBox.Enabled = false;
            this.northIncreaseBox.FormattingEnabled = true;
            this.northIncreaseBox.Location = new System.Drawing.Point(287, 228);
            this.northIncreaseBox.Name = "northIncreaseBox";
            this.northIncreaseBox.Size = new System.Drawing.Size(61, 21);
            this.northIncreaseBox.TabIndex = 6;
            this.northIncreaseBox.SelectedIndexChanged += new System.EventHandler(this.northIncreaseBox_SelectedIndexChanged);
            // 
            // premBox
            // 
            this.premBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.premBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.premBox.Enabled = false;
            this.premBox.FormattingEnabled = true;
            this.premBox.Location = new System.Drawing.Point(335, 88);
            this.premBox.Name = "premBox";
            this.premBox.Size = new System.Drawing.Size(61, 21);
            this.premBox.TabIndex = 2;
            this.premBox.SelectedIndexChanged += new System.EventHandler(this.premBox_SelectedIndexChanged);
            // 
            // secrBox
            // 
            this.secrBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.secrBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.secrBox.Enabled = false;
            this.secrBox.FormattingEnabled = true;
            this.secrBox.Location = new System.Drawing.Point(287, 123);
            this.secrBox.Name = "secrBox";
            this.secrBox.Size = new System.Drawing.Size(140, 21);
            this.secrBox.TabIndex = 3;
            this.secrBox.SelectedIndexChanged += new System.EventHandler(this.secrBox_SelectedIndexChanged);
            // 
            // expBox
            // 
            this.expBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.expBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.expBox.Enabled = false;
            this.expBox.FormattingEnabled = true;
            this.expBox.Location = new System.Drawing.Point(287, 158);
            this.expBox.Name = "expBox";
            this.expBox.Size = new System.Drawing.Size(121, 21);
            this.expBox.TabIndex = 4;
            this.expBox.SelectedIndexChanged += new System.EventHandler(this.expBox_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(374, 385);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "материальная помощь";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(315, 418);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "итого на руки";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(525, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "[...]";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(525, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "[...]";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(525, 196);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "[...]";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(525, 231);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "[...]";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(525, 91);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(22, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "[...]";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(525, 127);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "[...]";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(525, 347);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(22, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "[...]";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(525, 163);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(22, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "[...]";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(525, 385);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(22, 13);
            this.label19.TabIndex = 30;
            this.label19.Text = "[...]";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(445, 418);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(2, 22);
            this.label20.TabIndex = 31;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(463, 311);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 13);
            this.label21.TabIndex = 32;
            this.label21.Text = "итого";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(525, 311);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(22, 13);
            this.label22.TabIndex = 33;
            this.label22.Text = "[...]";
            // 
            // taxBox
            // 
            this.taxBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.taxBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.taxBox.Enabled = false;
            this.taxBox.Location = new System.Drawing.Point(287, 344);
            this.taxBox.Name = "taxBox";
            this.taxBox.Size = new System.Drawing.Size(61, 21);
            this.taxBox.TabIndex = 8;
            this.taxBox.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(12, 266);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(242, 13);
            this.label23.TabIndex = 35;
            this.label23.Text = "надбавка за особые условия военной службы";
            // 
            // specBox
            // 
            this.specBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.specBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.specBox.Enabled = false;
            this.specBox.FormattingEnabled = true;
            this.specBox.Location = new System.Drawing.Point(287, 263);
            this.specBox.Name = "specBox";
            this.specBox.Size = new System.Drawing.Size(61, 21);
            this.specBox.TabIndex = 7;
            this.specBox.SelectedIndexChanged += new System.EventHandler(this.specBox_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(525, 267);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(22, 13);
            this.label24.TabIndex = 37;
            this.label24.Text = "[...]";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(585, 520);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.specBox);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.taxBox);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.expBox);
            this.Controls.Add(this.secrBox);
            this.Controls.Add(this.premBox);
            this.Controls.Add(this.northIncreaseBox);
            this.Controls.Add(this.regionIncreaseBox);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.salRange);
            this.Controls.Add(this.rankBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.closeButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Калькулятор денежного довольствия военнослужащего";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox rankBox;
        private System.Windows.Forms.ComboBox salRange;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.ComboBox regionIncreaseBox;
        private System.Windows.Forms.ComboBox northIncreaseBox;
        private System.Windows.Forms.ComboBox premBox;
        private System.Windows.Forms.ComboBox secrBox;
        private System.Windows.Forms.ComboBox expBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox taxBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox specBox;
        private System.Windows.Forms.Label label24;

    }
}

