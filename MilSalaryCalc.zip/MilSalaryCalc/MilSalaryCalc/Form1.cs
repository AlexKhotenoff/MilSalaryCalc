﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MilSalaryCalc
{
    public partial class Form1 : Form
    {
        List<string[]> rankArr = new List<string[]>();
        List<string[]> salaryRange = new List<string[]>();
        List<string[]> secret = new List<string[]>();
        List<string[]> experience = new List<string[]>();

        public Form1()
        {
            InitializeComponent();
            Initialize();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Initialize()
        {
            rankArr.Add(new string[] { "рядовой", "5200" });
            rankArr.Add(new string[] { "ефрейтор", "5720" });
            rankArr.Add(new string[] { "младший сержант", "6240" });
            rankArr.Add(new string[] { "сержант", "6760" });
            rankArr.Add(new string[] { "старший сержант", "7280" });
            rankArr.Add(new string[] { "старшина", "7800" });
            rankArr.Add(new string[] { "прапорщик", "8320" });
            rankArr.Add(new string[] { "старший прапорщик", "8840" });
            rankArr.Add(new string[] { "матрос", "5200" });
            rankArr.Add(new string[] { "старший матрос", "5720" });
            rankArr.Add(new string[] { "старшина 2 статьи", "6240" });
            rankArr.Add(new string[] { "старшина 1 статьи", "6760" });
            rankArr.Add(new string[] { "главный старшина", "7280" });
            rankArr.Add(new string[] { "главный корабельный старшина", "7800" });
            rankArr.Add(new string[] { "мичман", "8320" });
            rankArr.Add(new string[] { "старий мичман", "8840" });

            salaryRange.Add(new string[] { "1 т.р.", "10400" });
            salaryRange.Add(new string[] { "2 т.р.", "11440" });
            salaryRange.Add(new string[] { "3 т.р.", "12480" });
            salaryRange.Add(new string[] { "4 т.р.", "13520" });
            salaryRange.Add(new string[] { "5 т.р.", "15600" });
            salaryRange.Add(new string[] { "6 т.р.", "16640" });
            salaryRange.Add(new string[] { "7 т.р.", "17680" });
            salaryRange.Add(new string[] { "8 т.р.", "18200" });
            salaryRange.Add(new string[] { "9 т.р.", "18720" });

            experience.Add(new string[] { "до 2 лет", "0" });
            experience.Add(new string[] { "от 2 до 5 лет", "10" });
            experience.Add(new string[] { "от 5 до 10 лет", "15" });
            experience.Add(new string[] { "от 10 до 15 лет", "20" });
            experience.Add(new string[] { "от 15 до 20 лет", "25" });
            experience.Add(new string[] { "от 20 до 25 лет", "30" });
            experience.Add(new string[] { "от 25 лет и более", "40" });

            secret.Add(new string[] { "нет", "0" });
            secret.Add(new string[] { "секретно", "10" });
            secret.Add(new string[] { "совершенно секретно", "20" });
            secret.Add(new string[] { "особой важности", "25" });

            for (int n = 0; n < rankArr.Count; n++)
            {
                this.rankBox.Items.Add(rankArr[n][0]);
            }

            for (int i = 0; i < salaryRange.Count; i++)
            {
                this.salRange.Items.Add(salaryRange[i][0]);
            }

            for (int m = 0; m < experience.Count; m++)
            {
                this.expBox.Items.Add(experience[m][0]);
            }

            for (int l = 0; l < secret.Count; l++)
            {
                this.secrBox.Items.Add(secret[l][0]);
            }

            for (int j = 0; j < 11; j++)
            {
                northIncreaseBox.Items.Add((j * 10).ToString() + "%");
                regionIncreaseBox.Items.Add((j * 10).ToString() + "%");
            }

            // northIncreaseBox.SelectedIndex = 0;
            // regionIncreaseBox.SelectedIndex = 0;

            for (int t = 0; t < 101; t++)
            {
                taxBox.Items.Add(t + "%");
            }

            for (int v = 0; v < 101; v+=5)
            {
                specBox.Items.Add(v + "%");
            }

            for (int k = 0; k < 6; k++)
            {
                premBox.Items.Add((k * 5).ToString() + "%");
            }

            // specBox.SelectedIndex = 0;
            taxBox.SelectedIndex = 13;
            //premBox.SelectedIndex = 0;
            //secrBox.SelectedIndex = 0;
        }

        private int GetPercent(double num, double percent)
        {
            if ((num >= 0) && (percent >= 0))
            {
                return (int)((percent * 100) / num);
            }
            else
            {
                return -1;
            }
        }

        private int GetFullSalary()
        {
            if ((salRange.SelectedIndex >= 0) && (rankBox.SelectedIndex >= 0))
            {
                int fullSalary = int.Parse(salaryRange[salRange.SelectedIndex][1]) +
                     int.Parse(rankArr[rankBox.SelectedIndex][1]);

                return fullSalary;
            }
            else
            {
                MessageBox.Show("Не введены данные об окладах");
                return -1;
            }
        }

        private int GetPremiumIncrease()
        {
            if ((salRange.SelectedIndex >= 0) && (rankBox.SelectedIndex >= 0)
                && (premBox.SelectedIndex >= 0))
            {
                double fullSalary = GetFullSalary();

                if ((fullSalary >= 0) && IsNumeric(premBox.SelectedItem.ToString().Trim('%')))
                {
                    double prem = fullSalary * (double.Parse(premBox.SelectedItem.ToString().Trim('%')) / 100);

                    return (int)prem;
                }
                else return -1;

            }
            else
            {
                //  MessageBox.Show("Не введены данные об окладах");
                return -1;
            }
        }

        private int GetSecretIncrease()
        {
            if (salRange.SelectedIndex < 0)
            {
                //MessageBox.Show("Не введены данные об окладе по должности");
                return -1;
            }

            if (secrBox.SelectedIndex >= 0)
            {
                double secrIncrease = double.Parse(salaryRange[salRange.SelectedIndex][1]) *
                    (double.Parse(secret[secrBox.SelectedIndex][1]) / 100);

                return (int)secrIncrease;
            }
            else
            {
                // MessageBox.Show("Не введены данные о допуске к гос. тайне");
                return -1;
            }
        }

        private int GetRegionIncrease()
        {
            if (regionIncreaseBox.SelectedIndex >= 0)
            {
                double fullSalary = GetFullSalary();

                if ((fullSalary >= 0) && IsNumeric(regionIncreaseBox.SelectedItem.ToString().Trim('%')))
                {
                    double secr = GetSecretIncrease();
                    if (secr < 0) secr = 0;

                    double exp = GetExperienceIncrease();
                    if (exp < 0) exp = 0;

                    double regIncr = (double.Parse(regionIncreaseBox.SelectedItem.ToString().Trim('%')) / 100) *
                        (secr + exp + fullSalary);

                    return (int)regIncr;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                // MessageBox.Show("Не введены данные по районному коэффициенту");
                return -1;
            }
        }

        private int GetNorthIncrease()
        {
            if (northIncreaseBox.SelectedIndex >= 0)
            {
                double fullSalary = GetFullSalary();

                if ((fullSalary >= 0) && IsNumeric(northIncreaseBox.SelectedItem.ToString().Trim('%')))
                {
                    double secr = GetSecretIncrease();
                    if (secr < 0) secr = 0;

                    double exp = GetExperienceIncrease();
                    if (exp < 0) exp = 0;

                    double northIncr = (double.Parse(northIncreaseBox.SelectedItem.ToString().Trim('%')) / 100) * (secr + exp + fullSalary);

                    return (int)northIncr;
                }
                else return -1;
            }
            else
            {
                //  MessageBox.Show("Не введены данные по северной надбавке");
                return -1;
            }
        }

        private int GetSpecialIncrease()
        {
            if (specBox.SelectedIndex >= 0)
            {
                double expSalary = int.Parse(salaryRange[salRange.SelectedIndex][1]);

                if ((expSalary >= 0) && IsNumeric(specBox.SelectedItem.ToString().Trim('%')))
                {

                    double secr = GetSecretIncrease();
                    if (secr < 0) secr = 0;

                    double exp = GetExperienceIncrease();
                    if (exp < 0) exp = 0;

                    double special = (double.Parse(specBox.SelectedItem.ToString().Trim('%')) / 100) * (expSalary);

                    return (int)special;
                }
                else
                {
                    return -1;
                }
            }
            else return -1;
        }

        private int GetExperienceIncrease()
        {
            if (expBox.SelectedIndex >= 0)
            {
                int fullSalary = GetFullSalary();

                if (fullSalary >= 0)
                {
                    double exp = fullSalary * (double.Parse(experience[expBox.SelectedIndex][1]) / 100);

                    return (int)exp;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                // MessageBox.Show("Не введены данные о выслуге лет");
                return -1;
            }
        }

        private bool IsNumeric(string input)
        {
            int result;
            if (!string.IsNullOrEmpty(input))
            {
                return int.TryParse(input, out result);
            }
            else { return false; }
        }

        private void rankBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = rankArr[rankBox.SelectedIndex][1] + " р.";

            if (salRange.SelectedIndex >= 0)
            {
                premBox.Enabled = true;
                secrBox.Enabled = true;
                expBox.Enabled = true;
                regionIncreaseBox.Enabled = true;
                northIncreaseBox.Enabled = true;
                specBox.Enabled = true;
                //taxBox.Enabled = true;
            }
        }

        private void salRange_SelectedIndexChanged(object sender, EventArgs e)
        {
            label12.Text = salaryRange[salRange.SelectedIndex][1] + " р.";

            if (rankBox.SelectedIndex >= 0)
            {
                premBox.Enabled = true;
                secrBox.Enabled = true;
                expBox.Enabled = true;
                regionIncreaseBox.Enabled = true;
                northIncreaseBox.Enabled = true;
                specBox.Enabled = true;
               // taxBox.Enabled = true;
            }
        }

        private void premBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int premium = GetPremiumIncrease();

            if (premium >= 0)
            {
                label15.Text = premium.ToString() + " р.";
            }
        }

        private void secrBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int secret = GetSecretIncrease();
            if (secret >= 0)
            {
                label16.Text = secret.ToString() + " р.";
            }
        }

        private void regionIncreaseBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int regIncr = GetRegionIncrease();
            if (regIncr >= 0)
            {
                label13.Text = regIncr.ToString() + " р.";
            }
        }

        private void expBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int exp = GetExperienceIncrease();
            if (exp >= 0) label18.Text = exp.ToString() + " р.";
        }

        private void northIncreaseBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int northIncr = GetNorthIncrease();
            if (northIncr >= 0)
            {
                label14.Text = northIncr.ToString() + " р.";
            }
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            if ((salRange.SelectedIndex >= 0) && (rankBox.SelectedIndex >= 0) && (taxBox.SelectedIndex >= 0))
            {
                if (IsNumeric(taxBox.SelectedItem.ToString().Trim('%')))
                {
                    double fullSalary = double.Parse(salaryRange[salRange.SelectedIndex][1]) +
                        double.Parse(rankArr[rankBox.SelectedIndex][1]);

                    int prem = GetPremiumIncrease();
                    if (prem < 0) prem = 0;

                    int secr = GetSecretIncrease();
                    if (secr < 0) secr = 0;

                    int exp = GetExperienceIncrease();
                    if (exp < 0) exp = 0;

                    int northIncr = GetNorthIncrease();
                    if (northIncr < 0) northIncr = 0;

                    int regIncr = GetRegionIncrease();
                    if (regIncr < 0) regIncr = 0;

                    int special = GetSpecialIncrease();
                    if (special < 0) special = 0;

                    label12.Text = int.Parse(salaryRange[salRange.SelectedIndex][1]).ToString() + " р.";
                    label11.Text = int.Parse(rankArr[rankBox.SelectedIndex][1]).ToString() + " р.";
                    label13.Text = regIncr.ToString() + " р.";
                    label14.Text = northIncr.ToString() + " р.";
                    label15.Text = prem.ToString() + " р.";
                    label16.Text = secr.ToString() + " р.";
                    label20.Text = ((fullSalary + prem + secr + exp + northIncr + regIncr + special) *
                        (1 - (double.Parse(taxBox.SelectedItem.ToString().Trim('%')) / 100))).ToString() + " р.";
                    label22.Text = (fullSalary + prem + secr + exp + northIncr + regIncr + special).ToString() + " р.";
                    label19.Text = (fullSalary * (1 - (double.Parse(taxBox.SelectedItem.ToString().Trim('%')) / 100))).ToString() + " р.";
                    label17.Text = ((fullSalary + prem + secr + exp + northIncr + regIncr) *
                        (double.Parse(taxBox.SelectedItem.ToString().Trim('%')) / 100)).ToString() + " р.";
                    label18.Text = exp.ToString() + " р.";
                    label24.Text = special.ToString() + " р.";
                }
            }
            else
            {
                MessageBox.Show("Заполнены не все поля!");
            }
        }

        private void specBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int special = GetSpecialIncrease();
            if (special >= 0) label24.Text = special.ToString()+" .р";
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Закрыть приложение?", "Выход",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == System.Windows.Forms.DialogResult.No) { e.Cancel = true; }
        }

    }
}
